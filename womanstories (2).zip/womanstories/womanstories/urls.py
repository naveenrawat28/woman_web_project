from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.views.static import serve
from django.shortcuts import render

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('Mainapp.urls')),
]

def custom_404(request, exception):
    return render(request, '404.html', status=404)

handler404 = custom_404

# ✅ Serve MEDIA even with DEBUG=False (for local/dev use only)
urlpatterns += [
    re_path(r'^media/(?P<path>.*)$', serve, {'document_root': settings.MEDIA_ROOT}),
]
