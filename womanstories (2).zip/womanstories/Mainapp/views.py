from django.shortcuts import render
from django.shortcuts import redirect
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from .forms import MagazineSubscriptionForm
from .models import *
from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.db.models import Count


categories_with_counts = BlogCategoryName.objects.annotate(blog_count=Count('blog')).filter(blog_count__gt=0)

########################################## Home Page #####################################

def home(request):
    banner = HomePageBanner.objects.last()
    about = HomeAboutSection.objects.last()
    service_section = HomePageServiceSection.objects.last() 
    services = Service.objects.all()
    workingflowdetails = WorkingFlow.objects.last()
    workingflowsteps = WorkingFlowStep.objects.all().order_by('step_number')
    brandsection = BrandSection.objects.last()
    brands = FeaturedBrand.objects.all().order_by('-id')[:15]
    testimonialsection = TestimonialSection.objects.last()
    testimonials = Testimonial.objects.all()

    features = ExclusiveFeature.objects.filter(live_status=True).order_by('-id')[:10]
    blogs = Blog.objects.filter(status=True).order_by('-date')[:10]

    top_lists = TopList.objects.filter(live_status=True).order_by('-id')[:3] 

    meta = PageMeta.objects.filter(page_name__iexact="Homepage").first()

    return render(request, 'home.html', {
        'banner': banner,
        'about': about,
        'service_section': service_section,
        'services': services,
        'workingflowsteps':workingflowsteps,
        'workingflowdetails' : workingflowdetails,
        'brandsection':brandsection,
        'brands':brands,
        'testimonialsection':testimonialsection,
        'testimonials':testimonials,
        'features':features,
        'blogs':blogs,
        'top_lists': top_lists,
        'meta':meta
    })


########################################## Interviews Page ###############################

def top_lists(request):
    banner = TopListBanner.objects.last()
    top_list_all = TopList.objects.filter(live_status=True).order_by('-id')
    recent_top_lists = top_list_all[:5]

    paginator = Paginator(top_list_all, 8)  
    page_number = request.GET.get('page')
    top_lists_page = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        list_html = render_to_string('top_lists_items.html', {'top_lists': top_lists_page}, request=request)
        pagination_html = render_to_string('top_lists_pagination.html', {'top_lists': top_lists_page}, request=request)
        return JsonResponse({'list_html': list_html, 'pagination_html': pagination_html})

    categories = BlogCategoryName.objects.annotate(blog_count=Count('blog')).filter(blog_count__gt=0)
    keyword_categories = BlogCategoryName.objects.all()

    meta = PageMeta.objects.filter(page_name__iexact="Top_Lists").first()

    return render(request, 'top-lists.html', {
        'banner': banner,
        'top_lists': top_lists_page, 
        'recent_top_lists': recent_top_lists,
        'categories': categories,
        'keyword_categories': keyword_categories,
        'meta':meta
    })

######################################### exclusive_features #############################

def exclusive_features(request):
    banner = ExclusiveFeaturesBanner.objects.last()

    feature_list = ExclusiveFeature.objects.filter(live_status=True).order_by('-id')
    recent_features = feature_list[:6]

    paginator = Paginator(feature_list, 24)
    page_number = request.GET.get('page')
    exclusive_page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        feature_html = render_to_string('exclusive_feature_items.html', {'features': exclusive_page_obj})
        pagination_html = render_to_string('exclusive_feature_pagination.html', {'features': exclusive_page_obj})
        return JsonResponse({'feature_html': feature_html, 'pagination_html': pagination_html})
    
    categories = BlogCategoryName.objects.annotate(blog_count=Count('blog')).filter(blog_count__gt=0)
    keyword_categories = BlogCategoryName.objects.all()

    meta = PageMeta.objects.filter(page_name__iexact="Exclusive_Features").first()

    return render(request, 'exclusive-features.html', {
        'banner': banner,
        'features': exclusive_page_obj,
        'recent_features': recent_features,
        'categories': categories,
        'keyword_categories':keyword_categories,
        'meta':meta
    })

###################################### Article Details Page ##############################

def article_details(request, slug):
    blog = get_object_or_404(Blog, slug=slug, status=True)

    previous_blog = Blog.objects.filter(status=True, id__lt=blog.id).order_by('-id').first()
    next_blog = Blog.objects.filter(status=True, id__gt=blog.id).order_by('id').first()

    related_blogs = Blog.objects.filter(
        blog_category=blog.blog_category,
        status=True
    ).exclude(id=blog.id).order_by('-date')[:10]

    recent_blog = Blog.objects.filter(
        status=True
    ).exclude(id=blog.id).order_by('-date')[:8]

    categories = BlogCategoryName.objects.annotate(blog_count=Count('blog')).filter(blog_count__gt=0)
    keyword_categories = BlogCategoryName.objects.all()

    meta = PageMeta.objects.filter(page_name__iexact="Article_Details").first()

    return render(request, 'article-details.html', {
        'blog': blog,
        'previous_blog': previous_blog,
        'next_blog': next_blog,
        'related_blogs': related_blogs,
        'recent_blog': recent_blog,
        'categories': categories,
        'keyword_categories':keyword_categories,
        'meta':meta

    })

################################### category -blog #####################################

def category_blogs(request, slug):
    category = get_object_or_404(BlogCategoryName, slug=slug)
    blogs = Blog.objects.filter(blog_category=category, status=True).order_by('-date')
    meta = PageMeta.objects.filter(page_name__iexact="Blog_Category").first()

    return render(request, 'category-blogs.html', {
        'category': category,
        'blogs': blogs,
        'meta':meta
    })

################################### top list details ####################################

def top_list_detail(request, slug):
    top_list_item = get_object_or_404(TopList, slug=slug, live_status=True)

    # Get previous item (smaller ID)
    prev_blog = TopList.objects.filter(live_status=True, id__lt=top_list_item.id).order_by('-id').first()

    # Get next item (greater ID)
    next_blog = TopList.objects.filter(live_status=True, id__gt=top_list_item.id).order_by('id').first()

    recent_top_lists = TopList.objects.filter(live_status=True).exclude(id=top_list_item.id).order_by('-id')[:6]
    recent_top_lists_10 = TopList.objects.filter(live_status=True).exclude(id=top_list_item.id).order_by('-id')[:10]

    categories = BlogCategoryName.objects.annotate(blog_count=Count('blog')).filter(blog_count__gt=0)
    keyword_categories = BlogCategoryName.objects.all()

    meta = PageMeta.objects.filter(page_name__iexact="Top_Lists_Detail").first()

    return render(request, 'top-list-details.html', {
        'item': top_list_item,
        'recent_top_lists': recent_top_lists,
        'recent_top_lists_10': recent_top_lists_10,
        'categories': categories,
        'keyword_categories': keyword_categories,
        'prev_blog': prev_blog,
        'next_blog': next_blog,
        'meta':meta
    })

################################- features-details-#######################################

def exclusive_features_details(request, slug):
    feature = get_object_or_404(ExclusiveFeature, slug=slug)

    featured_detail = ExclusiveFeaturedDetail.objects.filter(
        exclusive_feature=feature,
        position=1
    ).first()

    other_featured_details = ExclusiveFeaturedDetail.objects.filter(
        exclusive_feature=feature
    ).exclude(position=1)

    categories = BlogCategoryName.objects.annotate(blog_count=Count('blog')).filter(blog_count__gt=0)

    keyword_categories = BlogCategoryName.objects.all()

    recent_features = ExclusiveFeature.objects.filter(live_status=True).order_by('-id')[:8]

    more_recent_features = ExclusiveFeature.objects.filter(
        live_status=True
    ).exclude(id=feature.id).order_by('-id')[:20]

    meta = PageMeta.objects.filter(page_name__iexact="Exclusive_Features_Details").first()

    return render(request, 'exclusive-features-details.html', {
        'feature': feature,
        'featured_detail': featured_detail,
        'other_featured_details':other_featured_details,
        'categories': categories,
        'keyword_categories': keyword_categories,
        'recent_features': recent_features,
        'more_recent_features': more_recent_features,  
        'meta':meta
    })

################################- exclusive_feature_single_detail- #######################

def exclusive_feature_single_detail(request, feature_slug, slug):
    feature = get_object_or_404(ExclusiveFeature, slug=feature_slug)
    featured_detail = get_object_or_404(ExclusiveFeaturedDetail, slug=slug, exclusive_feature=feature)

    prev_detail = ExclusiveFeaturedDetail.objects.filter(
        exclusive_feature=feature,
        id__lt=featured_detail.id
    ).order_by('-id').first()

    next_detail = ExclusiveFeaturedDetail.objects.filter(
        exclusive_feature=feature,
        id__gt=featured_detail.id
    ).order_by('id').first()

    # Categories and Keywords
    categories = BlogCategoryName.objects.annotate(blog_count=Count('blog')).filter(blog_count__gt=0)
    keyword_categories = BlogCategoryName.objects.all()

    # Recent Features
    recent_features = ExclusiveFeature.objects.filter(live_status=True).order_by('-id')[:8]
    more_recent_features = ExclusiveFeature.objects.filter(live_status=True).order_by('-id')[:20]

    meta = PageMeta.objects.filter(page_name__iexact="Exclusive_Feature_Single_Detail").first()

    # Render the template
    return render(request, 'exclusive-feature-single-detail.html', {
        'feature': feature,
        'featured_detail': featured_detail,
        'prev_detail': prev_detail,
        'next_detail': next_detail,
        'categories': categories,
        'keyword_categories': keyword_categories,
        'recent_features': recent_features,
        'more_recent_features': more_recent_features,
        'meta':meta
    })


################################--magazine-details-######################################

def magazine_details(request, slug):
    feature = get_object_or_404(ExclusiveFeature, magazine_slug=slug)
    meta = PageMeta.objects.filter(page_name__iexact="Magazine_Details").first()
    return render(request, 'magazine-details.html', {'feature': feature,'meta':meta})

####################################### About Page #######################################

def about(request):
    banner = AboutPageBanner.objects.last()
    about_details = AboutPageDetails.objects.last()
    section = WhyChooseUs.objects.last()
    vision = OurVision.objects.last()  
    meta = PageMeta.objects.filter(page_name__iexact="About").first()
    return render(request, 'about.html', {
        'banner': banner,
        'about_details': about_details,
        'section': section,
        'vision': vision,
        'meta':meta
    })

###################################### FAQ Page ##########################################

def faq(request):
    banner = FaqPageBanner.objects.first()
    call_to_action = FaqPageCallToAction.objects.last()
    faq_items = FaqItem.objects.all()
    meta = PageMeta.objects.filter(page_name__iexact="FAQ").first()
    return render(request, 'faq.html', {
        'banner': banner,
        'cta': call_to_action,
        'faqs': faq_items,
        'meta':meta
    })

######################################## Contact Page ####################################

def contact(request):
    banner = ContactBannerDetail.objects.first()
    contact_data = ContactInfo.objects.all()
    meta = PageMeta.objects.filter(page_name__iexact="Contact").first()
    return render(request, 'contact.html', {
        'banner': banner,
        'contact_data': contact_data,
        'meta':meta
    })

######################################### My Team Page ###################################

def myteam(request):
    achievement = TeamAchievements.objects.first()
    banner = TeamPageBanner.objects.last()
    team_members = TeamMember.objects.all()
    achievements = Achievement.objects.order_by('number')
    meta = PageMeta.objects.filter(page_name__iexact="MyTeam").first()
    return render(request, 'team.html',{'achievement': achievement,
                                        'banner': banner,
                                        'team_members': team_members,
                                        'achievements': achievements,
                                        'meta':meta})

######################################## Blogs Page ######################################


def blogs(request):
    top_banner = BlogBanner.objects.first()
    blog_list = Blog.objects.filter(status=True).order_by('-date')
    paginator = Paginator(blog_list, 30)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    meta = PageMeta.objects.filter(page_name__iexact="Blogs").first()

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        blog_html = render_to_string('blog_items.html', {'blogs': page_obj})
        pagination_html = render_to_string('pagination.html', {'blogs': page_obj})
        return JsonResponse({'blog_html': blog_html, 'pagination_html': pagination_html})

    return render(request, 'blogs.html', {
        'blogs': page_obj,
        'top_banner': top_banner,
        'meta':meta
    })


######################################## Services Page ###################################

def services(request):
    banner = ServicePageBanner.objects.last()
    call_to_action = FaqPageCallToAction.objects.last()
    service_section = HomePageServiceSection.objects.last()
    services = Service.objects.all()
    benefit = BenefitSection.objects.last()

    meta = PageMeta.objects.filter(page_name__iexact="Services").first()

    context = {
        'banner': banner,
        'cta': call_to_action,
        'service_section': service_section,
        'services': services,
        'benefit': benefit,
        'meta':meta
    }
    return render(request, 'service.html', context)

###################################### Service Details Page ##############################

def service_details(request, slug):
    service = get_object_or_404(Service, slug=slug)
    faqs = ServiceFAQ.objects.filter(service=service)
    key_details = ServiceKeyDetail.objects.filter(service=service)
    other_services = Service.objects.exclude(id=service.id)

    meta = PageMeta.objects.filter(page_name__iexact="Service_Details").first()

    return render(request, 'service-details.html', {
        'service': service,
        'faqs': faqs,
        'key_details': key_details,
        'other_services': other_services,
        'meta':meta
    })

###################################### Team Details Page ##############################

def team_details(request, slug):
    member = get_object_or_404(TeamMember, slug=slug)
    meta = PageMeta.objects.filter(page_name__iexact="Team_Details").first()
    return render(request, 'team-details.html', {'member': member, 'meta':meta})

######################################-subscribe_magazine-#############################

def subscribe_magazine(request):
    if request.method == 'POST':
        form = MagazineSubscriptionForm(request.POST)
        if form.is_valid():
            subscriber = form.save()
            html_content = render_to_string('emails/magazine_welcome.html', {
                'subscriber': subscriber
            })
            email = EmailMessage(
                subject='Welcome to Woman Stories Magazine!',
                body=html_content,
                from_email='Woman Stories <nidhibhardwaj1231@gmail.com>',
                to=[subscriber.email],
            )
            email.content_subtype = 'html'

            try:
                email.send()
            except Exception as e:
                print(f"Error sending email: {e}")

    return redirect(request.META.get('HTTP_REFERER', '/'))

