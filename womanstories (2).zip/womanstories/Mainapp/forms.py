from django import forms
from .models import MagazineSubscriber

class MagazineSubscriptionForm(forms.ModelForm):
    class Meta:
        model = MagazineSubscriber
        fields = ['email']
        widgets = {
            'email': forms.EmailInput(attrs={
                'placeholder': 'Write your Email',
                'class': 'form-control',
            })
        }
