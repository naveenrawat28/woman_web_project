from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name='home'),
    path('top-lists/', top_lists, name='top_lists'),
    path('exclusive-features/', exclusive_features, name='exclusive_features'),
    path('exclusive-features-details/<slug:slug>/', exclusive_features_details, name='exclusive_features_details'),
    
    path('exclusive-features/<slug:feature_slug>/<slug:slug>/', exclusive_feature_single_detail, name='exclusive_feature_single_detail'),

    path('top-list/<slug:slug>/', top_list_detail, name='top_list_detail'),


    path('magazine-detail/<slug:slug>/', magazine_details, name='magazine_details'),
    
    path('about/', about,name='about'),
    path('faq/', faq, name='faq'),
    path('contact/', contact, name='contact'),
    path('my-team/', myteam, name='myteam'),
    
    path('blogs/', blogs, name='blogs'),
    path('blog-details/<slug:slug>/', article_details, name='article_details'),
    path('category/<slug:slug>/', category_blogs, name='category_blogs'),


    path('services/', services, name='services'),
    path('service-details/<slug:slug>/', service_details, name='service_details'),
    path('team-details/<slug:slug>/', team_details, name='team_details'),
    path('subscribe-magazine/', subscribe_magazine, name='subscribe_magazine'),
]
