from django.db import models
from ckeditor.fields import RichTextField
from django.utils.text import slugify

class FooterDetail(models.Model):
    slogan = models.TextField(verbose_name="Slogan")
    
    service_name_1 = models.CharField(max_length=100, verbose_name="Service Name 1")
    service_link_1 = models.URLField(verbose_name="Service Link 1", blank=True, null=True)

    service_name_2 = models.CharField(max_length=100, verbose_name="Service Name 2")
    service_link_2 = models.URLField(verbose_name="Service Link 2", blank=True, null=True)

    service_name_3 = models.CharField(max_length=100, verbose_name="Service Name 3", blank=True, null=True)
    service_link_3 = models.URLField(verbose_name="Service Link 3", blank=True, null=True)

    service_name_4 = models.CharField(max_length=100, verbose_name="Service Name 4", blank=True, null=True)
    service_link_4 = models.URLField(verbose_name="Service Link 4", blank=True, null=True)

    service_name_5 = models.CharField(max_length=100, verbose_name="Service Name 5", blank=True, null=True)
    service_link_5 = models.URLField(verbose_name="Service Link 5", blank=True, null=True)

    address = models.TextField(verbose_name="Address")
    email = models.EmailField(verbose_name="Email ID")
    mobile_1 = models.CharField(max_length=20, verbose_name="Mobile 1")
    mobile_2 = models.CharField(max_length=20, verbose_name="Mobile 2", blank=True, null=True)

    facebook_link = models.URLField(verbose_name="Facebook Link", blank=True, null=True)
    x_link = models.URLField(verbose_name="X (Twitter) Link", blank=True, null=True)
    instagram_link = models.URLField(verbose_name="Instagram Link", blank=True, null=True)
    linkedin_link = models.URLField(verbose_name="LinkedIn Link", blank=True, null=True)

    copyright_text = models.CharField(
        max_length=255,
        default="© 2025 Axency. All Rights Reserved.",
        verbose_name="Copyright Notice"
    )

    def __str__(self):
        return f"Footer Info: {self.slogan[:30]}"


##############################################################-MagazineSubscriber-#####################################################

class MagazineSubscriber(models.Model):
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email

###########################################################-home-page-banner-##########################################################

class HomePageBanner(models.Model):
    title_h1 = models.CharField("Title 1 (H1)", max_length=150)
    title_h2 = models.CharField("Title 2 (H2)", max_length=150)
    description = models.TextField("Short Description", max_length=500)
    main_image = models.ImageField(upload_to='homepage/banner/', help_text="Upload the main banner image")
    tagline = models.CharField("Tagline", max_length=100, help_text="Short phrase shown above or beside the title")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Homepage Banner"
        verbose_name_plural = "Homepage Banners"

    def __str__(self):
        return f"{self.title_h1} - Banner"
    
###########################################################-HomeAboutSection-###########################################################

class HomeAboutSection(models.Model):
    title_h2 = models.CharField("Main Title (H2)", max_length=200)
    title_h3 = models.CharField("Sub Title (H3)", max_length=200)
    description = models.TextField("Main Description", max_length=800)

    counter_1_title = models.CharField("Counter 1 Title", max_length=100)
    counter_1_value = models.CharField("Counter 1 Value", max_length=20, help_text="e.g., 14.6K")

    counter_2_title = models.CharField("Counter 2 Title", max_length=100)
    counter_2_value = models.CharField("Counter 2 Value", max_length=20, help_text="e.g., 200+")

    image_1 = models.ImageField(upload_to='about/images/', help_text="Upload first visual")
    image_2 = models.ImageField(upload_to='about/images/', help_text="Upload second visual")

    experience_years = models.CharField("Years of Experience", max_length=10, help_text="e.g., 10+")
    experience_title = models.CharField("Experience Title", max_length=150)
    experience_description = models.TextField("Experience Description", max_length=500)
    button_text = models.CharField(max_length=100, null=True, blank=True)
    button_url = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Homepage About Section"
        verbose_name_plural = "Homepage About Section"

    def __str__(self):
        return f"{self.title_h2} - About Section"

######################################################### service section #################################################################

class HomePageServiceSection(models.Model):
    title1 = models.CharField(max_length=200)
    title2 = models.CharField(max_length=200)
    description = models.TextField()
    button_text = models.CharField(max_length=100)
    button_url = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return f"{self.title1} - {self.title2}"

############################################################# service ######################################################################

class Service(models.Model):
    meta_title = models.CharField(
    max_length=70,
    verbose_name="Meta Title",
    blank=True,
    null=True
    )
    meta_description = models.TextField(
        verbose_name="Meta Description",
        blank=True,
        null=True,
        help_text="Recommended length: up to 160 characters"
    )
    meta_keywords = models.TextField(
        verbose_name="Meta Keywords",
        blank=True,
        null=True,
        help_text="Comma-separated keywords"
    )


    service_name = models.CharField(max_length=200)
    image = models.ImageField(upload_to='services/', help_text="Upload image of size 1316x562 pixels")
    image_secondary = models.ImageField(upload_to='services/', null=True, blank=True, help_text="Upload image of size 462x445 pixels") 
    service_title_h2 = models.CharField(max_length=255)
    slug = models.SlugField(unique=True, blank=True)
    description = RichTextField(help_text="Main HTML-formatted description (uses CKEditor)")
    description_lets_talk = models.TextField(help_text="Plain description for 'Let's Talk' section")
    faq_title_1 = models.CharField(max_length=255)
    faq_title_2 = models.CharField(max_length=255)
    faq_description = models.TextField()
    faq_button_text = models.CharField(max_length=100, null=True, blank=True)
    faq_button_url = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.service_name

############################################################ service faqs ######################################################################

class ServiceFAQ(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='faqs')
    question = models.CharField(max_length=300)
    answer = RichTextField(help_text="Use CKEditor for formatted answers")

    def __str__(self):
        return f"FAQ for {self.service.service_name}: {self.question}"
    
############################################################# ServiceKeyDetail ##################################################################

class ServiceKeyDetail(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='key_details')
    title_h4 = models.CharField(max_length=255)
    description = RichTextField(help_text="Use CKEditor for formatted content")

    def __str__(self):
        return f"{self.title_h4} - {self.service.service_name}"
    
############################################################# WorkingFlow #######################################################################

class WorkingFlow(models.Model):
    title_1 = models.CharField(max_length=255)
    title_2 = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField()

    def __str__(self):
        return self.title_1
    
############################################################# WorkingFlowStep ##################################################################

class WorkingFlowStep(models.Model):
    step_number = models.PositiveIntegerField()
    title = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return f"Step {self.step_number}: {self.title}"

############################################################# BrandSection ######################################################################

class BrandSection(models.Model):
    title = models.CharField(max_length=255)
    image1 = models.ImageField(upload_to='brand_images/', blank=True, null=True)
    image2 = models.ImageField(upload_to='brand_images/', blank=True, null=True)
    image3 = models.ImageField(upload_to='brand_images/', blank=True, null=True)
    image4 = models.ImageField(upload_to='brand_images/', blank=True, null=True)
    description = models.TextField()

    def __str__(self):
        return self.title

###################################################### Brand ###################################################################################

class FeaturedBrand(models.Model):
    brand_name = models.CharField(max_length=255)
    brand_logo = models.ImageField(upload_to='brand_logos/')

    def __str__(self):
        return self.brand_name
    
##################################################### TestimonialSection ######################################################################

class TestimonialSection(models.Model):
    title1 = models.CharField(max_length=255)
    title2 = models.CharField(max_length=255)
    image = models.ImageField(upload_to='testimonials/')

    def __str__(self):
        return self.title1

###################################################### Testimonial ############################################################################

class Testimonial(models.Model):
    message = models.TextField()
    person_name = models.CharField(max_length=255)
    person_designation = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.person_name} – {self.person_designation}"

###################################################### AboutPageBanner ########################################################################

class AboutPageBanner(models.Model):
    title_h1 = models.CharField(max_length=255)
    title_h2 = models.CharField(max_length=255)
    description = RichTextField()

    def __str__(self):
        return self.title_h1
    
##################################################### AboutPageDetails #######################################################################

class AboutPageDetails(models.Model):
    title_h2 = models.CharField(max_length=255)
    title_h3 = models.CharField(max_length=255)
    description = RichTextField()
    demo_video_link = models.URLField(blank=True, null=True)
    image = models.ImageField(upload_to='about_images/', blank=True, null=True)

    stat1_value = models.CharField(max_length=20, help_text="e.g., 340+")
    stat1_label = models.CharField(max_length=100, help_text="e.g., Completed Projects")

    stat2_value = models.CharField(max_length=20)
    stat2_label = models.CharField(max_length=100)

    stat3_value = models.CharField(max_length=20)
    stat3_label = models.CharField(max_length=100)

    stat4_value = models.CharField(max_length=20)
    stat4_label = models.CharField(max_length=100)

    def __str__(self):
        return self.title_h2

##################################################### WhyChooseUs ############################################################################

class WhyChooseUs(models.Model):
    title_1 = models.CharField(max_length=255, verbose_name="Main Title H2")
    title_2 = models.CharField(max_length=255, verbose_name="Sub Title H3")
    description = models.TextField()

    image1 = models.ImageField(upload_to='why_choose_us/', help_text="Recommended size: 290x292px")
    image2 = models.ImageField(upload_to='why_choose_us/', help_text="Recommended size: 290x360px")

    section1_icon = models.ImageField(upload_to='why_choose_us/icons/', help_text="Icon for Section 1")
    section1_title = models.CharField(max_length=255)
    section1_description = models.TextField()

    section2_icon = models.ImageField(upload_to='why_choose_us/icons/', help_text="Icon for Section 2")
    section2_title = models.CharField(max_length=255)
    section2_description = models.TextField()

    section3_icon = models.ImageField(upload_to='why_choose_us/icons/', help_text="Icon for Section 3")
    section3_title = models.CharField(max_length=255)
    section3_description = models.TextField()

    section4_icon = models.ImageField(upload_to='why_choose_us/icons/', help_text="Icon for Section 4")
    section4_title = models.CharField(max_length=255)
    section4_description = models.TextField()

    def __str__(self):
        return self.title_1

################################################### OurVision #############################################################################

class OurVision(models.Model):
    title_1 = models.CharField(max_length=255)
    title_2 = models.CharField(max_length=255)
    description = RichTextField()
    image = models.ImageField(upload_to='our_vision/')

    def __str__(self):
        return self.title_1
    
################################################## ContactBannerDetail ####################################################################

class ContactBannerDetail(models.Model):
    title_h1 = models.CharField(max_length=255)
    title_h2 = models.CharField(max_length=255, blank=True, null=True)
    description = RichTextField()
    image_1 = models.ImageField(upload_to='contact_banner/', blank=True, null=True)
    image_2 = models.ImageField(upload_to='contact_banner/', blank=True, null=True)
    map_embed_url = models.TextField(blank=True, null=True, help_text="Paste Google Maps iframe embed code here")

    def __str__(self):
        return self.title_h1

################################################ ContactInfo ###############################################################################

class ContactInfo(models.Model):
    office_title = models.CharField(max_length=100, default="Office")
    address = models.TextField()
    phone_number_primary = models.CharField(max_length=20)
    phone_number_secondary = models.CharField(max_length=20, blank=True, null=True)
    email_primary = models.EmailField()
    email_secondary = models.EmailField(blank=True, null=True)

    def __str__(self):
        return f"{self.office_title} - {self.address[:30]}..."
    
###################################################### FaqPageBanner ########################################################################

class FaqPageBanner(models.Model):
    title_h1 = models.CharField(max_length=255)
    title_h2 = models.CharField(max_length=255)
    description = RichTextField()

    def __str__(self):
        return self.title_h1
    
####################################################### FaqPageCallToAction ################################################################

class FaqPageCallToAction(models.Model):
    title_1 = models.CharField(max_length=255)
    title_2 = models.CharField(max_length=255)
    description = models.TextField()
    button_text = models.CharField(max_length=100)
    button_link = models.CharField(max_length=500)
    live_chat_button_name = models.CharField(max_length=100)
    live_chat_button_link = models.URLField(max_length=500)
    mail_id = models.EmailField()
    image_1 = models.ImageField(upload_to='faq_cta_images/')
    image_2 = models.ImageField(upload_to='faq_cta_images/')

    def __str__(self):
        return self.title_1
    
######################################################## FaqItem ############################################################################

class FaqItem(models.Model):
    question = models.CharField(max_length=255)
    answer = models.TextField()

    def __str__(self):
        return self.question
    
###################################################### ServicePageBanner ####################################################################

class ServicePageBanner(models.Model):
    title_h1 = models.CharField(max_length=255)
    description = models.TextField()
    tagline = models.CharField(max_length=255)
    image = models.ImageField(upload_to='service_banners/')

    def __str__(self):
        return self.title_h1
    
###################################################### BenefitSection ########################################################################

class BenefitSection(models.Model):
    title_1 = models.CharField(max_length=255)
    title_2 = models.CharField(max_length=255)
    description = RichTextField()

    image_1 = models.ImageField(upload_to='benefit_section/')
    image_2 = models.ImageField(upload_to='benefit_section/')
    image_3 = models.ImageField(upload_to='benefit_section/', null=True, blank=True)
    image_4 = models.ImageField(upload_to='benefit_section/', null=True, blank=True)

    icon_1 = models.ImageField(upload_to='benefit_section/icons/', null=True, blank=True)
    title_1_benefit = models.CharField(max_length=255, null=True, blank=True)
    description_1 = models.TextField(null=True, blank=True)

    icon_2 = models.ImageField(upload_to='benefit_section/icons/', null=True, blank=True)
    title_2_benefit = models.CharField(max_length=255, null=True, blank=True)
    description_2 = models.TextField(null=True, blank=True)

    icon_3 = models.ImageField(upload_to='benefit_section/icons/', null=True, blank=True)
    title_3_benefit = models.CharField(max_length=255, null=True, blank=True)
    description_3 = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.title_1

############################################################## TeamAchievements #################################################################

class TeamAchievements(models.Model):
    title_1 = models.CharField(
        max_length=255,
        help_text="Main heading (e.g., 'Developing and maintaining')"
    )
    title_2 = models.CharField(
        max_length=255,
        help_text="Secondary heading or emphasized title (e.g., 'consistent visual')"
    )
    description = RichTextField(
        help_text="Full descriptive paragraph with rich formatting"
    )
    achievement_count = models.PositiveIntegerField(
        help_text="Numeric value for achievements (e.g., 200)"
    )
    achievement_title = models.CharField(
        max_length=255,
        help_text="Label for the count (e.g., 'Projects Completed')"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Team Achievement"
        verbose_name_plural = "Team Achievements"

    def __str__(self):
        return f"{self.title_1} {self.title_2}"
    
####################################################################### TeamPageBanner ########################################################

class TeamPageBanner(models.Model):
    title_h1 = models.CharField(max_length=255)
    description = models.TextField()
    tagline = models.CharField(max_length=255)
    image = models.ImageField(upload_to='service_banners/')

    def __str__(self):
        return self.title_h1
    
###################################################################### TeamMember #############################################################

class TeamMember(models.Model):
    name = models.CharField(max_length=100)
    short_info = models.CharField(max_length=500)
    description = models.TextField()
    employee_image = models.ImageField(upload_to='team_members/', blank=True, null=True)
    label1 = models.CharField(max_length=100, blank=True, null=True)
    value1 = models.CharField(max_length=100, blank=True, null=True)
    label2 = models.CharField(max_length=100, blank=True, null=True)
    value2 = models.CharField(max_length=100, blank=True, null=True)
    label3 = models.CharField(max_length=100, blank=True, null=True)
    value3 = models.CharField(max_length=100, blank=True, null=True)
    label4 = models.CharField(max_length=100, blank=True, null=True)
    value4 = models.CharField(max_length=100, blank=True, null=True)
    slug = models.SlugField(blank=True, null=True)

    facebook_link = models.URLField(blank=True, null=True)
    x_link = models.URLField(blank=True, null=True) 
    instagram_link = models.URLField(blank=True, null=True)
    linkedin_link = models.URLField(blank=True, null=True)

    career_guideline = RichTextField(blank=True, null=True)

    skill1_name = models.CharField(max_length=100, blank=True, null=True)
    skill1_percent = models.PositiveIntegerField(blank=True, null=True)

    skill2_name = models.CharField(max_length=100, blank=True, null=True)
    skill2_percent = models.PositiveIntegerField(blank=True, null=True)

    skill3_name = models.CharField(max_length=100, blank=True, null=True)
    skill3_percent = models.PositiveIntegerField(blank=True, null=True)

    highlight_text = models.CharField(
        max_length=100, 
        blank=True, 
        null=True,
        help_text="Example: '50+ Award Winning'"
    )

    def __str__(self):
        return self.name

############################################################### Achievement ##########################################################################

class Achievement(models.Model):
    number = models.PositiveIntegerField()
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='achievements/')

    def __str__(self):
        return f"{self.number:02d} - {self.title}"
    
############################################################### SocialModelLinks ##########################################################################

class SocialModelLinks(models.Model):
    facebook_link = models.URLField(blank=True, null=True)
    linkedin_link = models.URLField(blank=True, null=True)
    instagram_link = models.URLField(blank=True, null=True)
    x_link = models.URLField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Social Links ({self.id})"
    
############################################################## TopListBanner #############################################################################

class TopListBanner(models.Model):
    title_h1 = models.CharField(max_length=255, verbose_name="Title H1")
    title_h2 = models.CharField(max_length=255, verbose_name="Title H2")
    description = RichTextField(verbose_name="Rich Description")

    def __str__(self):
        return self.title_h1
    
############################################################## ExclusiveFeaturesBanner #############################################################################

class ExclusiveFeaturesBanner(models.Model):
    title_h1 = models.CharField(max_length=255, verbose_name="Title H1")
    title_h2 = models.CharField(max_length=255, verbose_name="Title H2")
    description = RichTextField(verbose_name="Rich Description")

    def __str__(self):
        return self.title_h1
    
############################################################ BlogBanner ###########################################################################################

class BlogBanner(models.Model):
    h1_title = models.CharField(max_length=200, verbose_name="H1 Title")
    h2_title = models.CharField(max_length=200, verbose_name="H2 Title", blank=True)
    description = RichTextField(verbose_name="Description", blank=True) 
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Blog Banner"
        verbose_name_plural = "Blog Banners"

    def __str__(self):
        return self.h1_title

################################################################ BlogCategoryName #########################################################################

class BlogCategoryName(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name="Category Name")
    slug = models.SlugField(max_length=120, unique=True, verbose_name="URL Slug")
    created_at = models.DateTimeField(auto_now_add=True)

    # SEO Meta Fields
    meta_title = models.CharField(max_length=70, verbose_name="Meta Title", blank=True, null=True)
    meta_description = models.CharField(max_length=160, verbose_name="Meta Description", blank=True, null=True)
    meta_keywords = models.CharField(max_length=255, verbose_name="Meta Keywords", blank=True, null=True)

    # Banner Content
    banner_h1 = models.CharField(max_length=150, verbose_name="Banner Heading (H1)", blank=True, null=True)
    banner_h2 = models.CharField(max_length=250, verbose_name="Banner Subheading (H2)", blank=True, null=True)
    banner_description = RichTextField(verbose_name="Banner Description", blank=True, null=True)

    def __str__(self):
        return self.name
    
################################################################  Author ##################################################################################

class Author(models.Model):
    name = models.CharField(max_length=100, verbose_name="Author Name")
    image = models.ImageField(upload_to='authors/', verbose_name="Author Image", blank=True, null=True)
    
    facebook = models.URLField(max_length=255, blank=True, null=True, verbose_name="Facebook URL")
    twitter = models.URLField(max_length=255, blank=True, null=True, verbose_name="X (Twitter) URL")
    instagram = models.URLField(max_length=255, blank=True, null=True, verbose_name="Instagram URL")
    linkedin = models.URLField(max_length=255, blank=True, null=True, verbose_name="LinkedIn URL")

    def __str__(self):
        return self.name

    
############################################################### Blog #################################################################################

class Blog(models.Model):
    meta_title = models.CharField(max_length=70, verbose_name="Meta Title")
    meta_description = models.CharField(max_length=160, verbose_name="Meta Description")
    meta_keywords = models.CharField(max_length=255, verbose_name="Meta Keywords")
    slug = models.SlugField(max_length=120, unique=True, verbose_name="Slug")

    author = models.ForeignKey('Author', on_delete=models.SET_NULL, null=True, blank=True)
    blog_category = models.ForeignKey('BlogCategoryName', on_delete=models.SET_NULL, null=True, blank=True)

    title_h1 = models.CharField(max_length=200, verbose_name="H1 Title")
    description = RichTextField(verbose_name="Content Description")

    feature_image = models.ImageField(upload_to='blog/feature_images/', verbose_name="Main Feature Image", null=True, blank=True)
    banner_image = models.ImageField(upload_to='blog/banner_images/', verbose_name="Banner Image", null=True, blank=True)

    date = models.DateField(verbose_name="Published Date", help_text="Set the publish date manually")
    tags = models.CharField(max_length=255, verbose_name="Tags (comma separated)", blank=True)

    status = models.BooleanField(default=True, verbose_name="Publish Status")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    def __str__(self):
        return self.title_h1

    def tag_list(self):
        return [tag.strip() for tag in self.tags.split(',') if tag.strip()]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title_h1)
        super().save(*args, **kwargs)

#######################################################################################################################

class BlogDetail(models.Model):
    blog = models.ForeignKey('Blog', on_delete=models.CASCADE, related_name='details')
    title = models.CharField(max_length=200, verbose_name="Title")
    description = RichTextField(verbose_name="Description", blank=True, null=True)
    image = models.ImageField(upload_to='blog/detail_images/', verbose_name="Image")
    alt_text = models.CharField(max_length=255, verbose_name="Alt Text", help_text="Image alt text for SEO and accessibility")

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Blog Detail"
        verbose_name_plural = "Blog Details"

    def __str__(self):
        return f"{self.title} ({self.blog.title_h1})"


########################################################################################################################

class ExclusiveFeature(models.Model):
    meta_title = models.CharField(max_length=255, verbose_name="Meta Title")
    meta_description = models.TextField(verbose_name="Meta Description")
    meta_keywords = models.CharField(max_length=255, verbose_name="Meta Keywords")
    slug = models.SlugField(max_length=255, unique=True, verbose_name="URL Slug")

    author = models.ForeignKey('Author', on_delete=models.SET_NULL, null=True, blank=True)
    category = models.ForeignKey('BlogCategoryName', on_delete=models.SET_NULL, null=True, blank=True)

    main_title = models.CharField(max_length=255, verbose_name="Main Title")
    featured_image = models.ImageField(upload_to='exclusive_features/', verbose_name="Featured Image")
    uploaded_date = models.DateField(verbose_name="Uploaded Date")  

    live_status = models.BooleanField(default=False, verbose_name="Live Status")

    magazine_iframe = models.TextField(blank=True, null=True, verbose_name="Magazine Iframe")
    magazine_status = models.BooleanField(default=False, verbose_name="Magazine Status")
    magazine_slug = models.SlugField(max_length=255, blank=True, null=True, verbose_name="Magazine Slug")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Exclusive Feature"
        verbose_name_plural = "Exclusive Features"

    def __str__(self):
        return self.main_title
    
########################################################################################################################

class ExclusiveFeaturedDetail(models.Model):
    # SEO Fields
    meta_title = models.CharField(max_length=255, verbose_name="Meta Title")
    meta_description = models.TextField(verbose_name="Meta Description")
    meta_keywords = models.CharField(max_length=255, verbose_name="Meta Keywords")
    slug = models.SlugField(max_length=255, unique=True, verbose_name="URL Slug")

    exclusive_feature = models.ForeignKey(
        'ExclusiveFeature',
        on_delete=models.CASCADE,
        related_name='featured_details',
        verbose_name="Linked Exclusive Feature"
    )

    title = models.CharField(max_length=255, verbose_name="Title")
    description = RichTextField(verbose_name="Description")

    banner_image = models.ImageField(upload_to='exclusive_featured_details/', verbose_name="Banner Image")
    alt_text = models.CharField(max_length=255, verbose_name="Image Alt Text")

    profile_summary = models.CharField(
        max_length=255,
        verbose_name="Name, Designation & Position (e.g., John Doe – CEO)",
        blank=True,
        null=True 
    )

    story_type = models.CharField(
        max_length=100,
        verbose_name="Story Type (e.g., Cover Story, Interview, etc.)",
        blank=True,
        null=True
    )

    position = models.IntegerField(
        verbose_name="Position Number",
        blank=True,
        null=True,
        help_text="Enter numeric position (e.g., 1, 2, 3...)"
    )

    tags = models.CharField(max_length=255, verbose_name="Tags (comma separated)", blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Exclusive Featured Detail"
        verbose_name_plural = "Exclusive Featured Details"

    def __str__(self):
        return self.title

#################################################################################################################

class TopList(models.Model):
    meta_title = models.CharField(max_length=255, verbose_name="Meta Title")
    meta_description = models.TextField(verbose_name="Meta Description")
    meta_keywords = models.CharField(max_length=255, verbose_name="Meta Keywords")
    slug = models.SlugField(max_length=255, unique=True, verbose_name="URL Slug")

    title = models.CharField(max_length=255, verbose_name="Title")
    description = RichTextField(verbose_name="Description (Rich Text)")

    banner_image = models.ImageField(upload_to='top_list_banners/', verbose_name="Banner Image")
    banner_image_alt = models.CharField(max_length=255, verbose_name="Banner Image Alt Text")

    author = models.ForeignKey('Author', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Author")

    tags = models.CharField(max_length=255, verbose_name="Tags (comma separated)", blank=True)
    live_status = models.BooleanField(default=False, verbose_name="Live Status")

    created_at = models.DateTimeField(verbose_name="Created At", help_text="Set the created date manually")
    updated_at = models.DateTimeField(verbose_name="Updated At", help_text="Set the updated date manually")

    class Meta:
        verbose_name = "Top List"
        verbose_name_plural = "Top Lists"

    def __str__(self):
        return self.title
    
#################################################################################################################

class TopListDetail(models.Model):
    top_list = models.ForeignKey(
        'TopList',
        on_delete=models.CASCADE,
        related_name='details',
        verbose_name="Related Top List"
    )
    title = models.CharField(max_length=255, verbose_name="Title")
    description = RichTextField(verbose_name="Description (Rich Text)")

    feature_image = models.ImageField(upload_to='top_list_details/', verbose_name="Feature Image")
    feature_image_alt_text = models.CharField(max_length=255, verbose_name="Feature Image Alt Text")

    created_at = models.DateTimeField(verbose_name="Created At", help_text="Set the created date manually")
    updated_at = models.DateTimeField(verbose_name="Updated At", help_text="Set the updated date manually")


    class Meta:
        verbose_name = "Top List Detail"
        verbose_name_plural = "Top List Details"

    def __str__(self):
        return self.title
    
####################################################################################################################

class PageMeta(models.Model):
    page_name = models.CharField(max_length=100, verbose_name="Page Name", blank=True, null=True)
    title = models.CharField(max_length=200, verbose_name="HTML <title>", blank=True, null=True)
    meta_title = models.CharField(max_length=200, verbose_name="Meta Title", blank=True, null=True)
    meta_description = models.TextField(verbose_name="Meta Description", blank=True, null=True)
    meta_keywords = models.CharField(max_length=300, verbose_name="Meta Keywords", blank=True, null=True)
    canonical_url = models.URLField(verbose_name="Canonical URL", blank=True, null=True)

    # Twitter Meta Tags
    twitter_card = models.CharField(max_length=50, verbose_name="Twitter Card Type", blank=True, null=True)
    twitter_site = models.CharField(max_length=100, verbose_name="Twitter Site Handle", blank=True, null=True)
    twitter_creator = models.CharField(max_length=100, verbose_name="Twitter Creator Handle", blank=True, null=True)
    twitter_title = models.CharField(max_length=200, verbose_name="Twitter Title", blank=True, null=True)
    twitter_image = models.ImageField(upload_to="seo/twitter/", verbose_name="Twitter Image", blank=True, null=True)
    twitter_image_alt = models.CharField(max_length=100, verbose_name="Twitter Image Alt Text", blank=True, null=True)

    # Open Graph Meta Tags
    og_title = models.CharField(max_length=200, verbose_name="OG Title", blank=True, null=True)
    og_url = models.URLField(verbose_name="OG URL", blank=True, null=True)
    og_image = models.ImageField(upload_to="seo/opengraph/", verbose_name="OG Image", blank=True, null=True)
    og_image_type = models.CharField(max_length=50, verbose_name="OG Image Type", blank=True, null=True)
    og_image_width = models.IntegerField(verbose_name="OG Image Width", blank=True, null=True)
    og_image_height = models.IntegerField(verbose_name="OG Image Height", blank=True, null=True)
    og_type = models.CharField(max_length=50, verbose_name="OG Type", blank=True, null=True)
    og_locale = models.CharField(max_length=20, verbose_name="OG Locale", blank=True, null=True)
    og_image_url = models.ImageField(upload_to="seo/opengraph/", verbose_name="OG Image (duplicate tag)", blank=True, null=True)
    og_image_secure_url = models.ImageField(upload_to="seo/opengraph/", verbose_name="OG Image Secure URL", blank=True, null=True)
    og_site_name = models.CharField(max_length=200, verbose_name="OG Site Name", blank=True, null=True)
    og_see_also = models.CharField(max_length=200, verbose_name="OG See Also", blank=True, null=True)

    # Additional Meta
    article_author = models.CharField(max_length=200, verbose_name="Article Author", blank=True, null=True)
    google_site_verification = models.CharField(
        max_length=200,
        verbose_name="Google Site Verification",
        blank=True,
        null=True,
    )

    def __str__(self):
        return self.page_name if self.page_name else "Untitled Page"

    class Meta:
        verbose_name = "Page Metadata"
        verbose_name_plural = "Page Metadata"
