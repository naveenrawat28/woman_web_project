from django.contrib import admin
from .models import *
from django.utils.html import format_html

@admin.register(FooterDetail)
class FooterDetailAdmin(admin.ModelAdmin):
    list_display = ('slogan', 'email', 'mobile_1') 
    search_fields = ('slogan', 'email', 'address')

########################################################################################################

@admin.register(MagazineSubscriber)
class MagazineSubscriberAdmin(admin.ModelAdmin):
    list_display = ('email', 'subscribed_at')
    search_fields = ('email',)

########################################################################################################

@admin.register(HomePageBanner)
class HomePageBannerAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'tagline', 'created_at')
    search_fields = ('title_h1', 'tagline')

########################################################################################################

@admin.register(HomeAboutSection)
class HomeAboutSectionAdmin(admin.ModelAdmin):
    list_display = ('title_h2', 'experience_years')
    search_fields = ('title_h2', 'experience_title')

########################################################################################################

@admin.register(HomePageServiceSection)
class HomePageServiceSectionAdmin(admin.ModelAdmin):
    list_display = ('title1', 'title2', 'button_text', 'button_url')
    search_fields = ('title1', 'title2', 'description')

class ServiceFAQInline(admin.TabularInline):
    model = ServiceFAQ
    extra = 1

class ServiceKeyDetailInline(admin.TabularInline):
    model = ServiceKeyDetail
    extra = 1

########################################################################################################

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('service_name', 'service_title_h2')
    search_fields = ('service_name', 'service_title_h2', 'faq_title_1', 'faq_title_2')
    prepopulated_fields = {'slug': ('service_name',)}
    inlines = [ServiceFAQInline, ServiceKeyDetailInline] 

########################################################################################################

@admin.register(ServiceFAQ)
class ServiceFAQAdmin(admin.ModelAdmin):
    list_display = ('service', 'question')
    search_fields = ('question', 'answer')
    list_filter = ('service',)

########################################################################################################

@admin.register(ServiceKeyDetail)
class ServiceKeyDetailAdmin(admin.ModelAdmin):
    list_display = ('service', 'title_h4')
    search_fields = ('title_h4', 'description')
    list_filter = ('service',)

########################################################################################################

@admin.register(WorkingFlow)
class WorkingFlowAdmin(admin.ModelAdmin):
    list_display = ('title_1', 'title_2')
    search_fields = ('title_1', 'title_2', 'description')

########################################################################################################

@admin.register(WorkingFlowStep)
class WorkingFlowStepAdmin(admin.ModelAdmin):
    list_display = ('step_number', 'title')
    search_fields = ('title', 'description')
    list_filter = ('step_number',)

########################################################################################################

@admin.register(BrandSection)
class BrandSectionAdmin(admin.ModelAdmin):
    list_display = ('title',)
    search_fields = ('title', 'description')

########################################################################################################

@admin.register(FeaturedBrand)
class FeaturedBrandAdmin(admin.ModelAdmin):
    list_display = ('brand_name',)
    search_fields = ('brand_name',)

########################################################################################################

@admin.register(TestimonialSection)
class TestimonialSectionAdmin(admin.ModelAdmin):
    list_display = ('title1', 'title2', 'image')
    search_fields = ('title1', 'title2')

########################################################################################################

@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ('person_name', 'person_designation')
    search_fields = ('person_name', 'person_designation')

########################################################################################################

@admin.register(AboutPageBanner)
class AboutPageBannerAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'title_h2')
    search_fields = ('title_h1', 'title_h2')

########################################################################################################

@admin.register(AboutPageDetails)
class AboutPageDetailsAdmin(admin.ModelAdmin):
    list_display = ('title_h2', 'title_h3')
    search_fields = ('title_h2', 'title_h3')

########################################################################################################

@admin.register(WhyChooseUs)
class WhyChooseUsAdmin(admin.ModelAdmin):
    list_display = ('title_1', 'title_2')
    search_fields = ('title_1', 'title_2')

########################################################################################################

@admin.register(OurVision)
class OurVisionAdmin(admin.ModelAdmin):
    list_display = ('title_1', 'title_2')
    search_fields = ('title_1', 'title_2')

########################################################################################################

@admin.register(ContactBannerDetail)
class ContactBannerDetailAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'title_h2')
    search_fields = ('title_h1', 'title_h2')

########################################################################################################

@admin.register(ContactInfo)
class ContactInfoAdmin(admin.ModelAdmin):
    list_display = ('office_title', 'phone_number_primary', 'email_primary')
    search_fields = ('office_title', 'phone_number_primary', 'email_primary', 'address')

########################################################################################################

@admin.register(FaqPageBanner)
class FaqPageBannerAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'title_h2')
    search_fields = ('title_h1', 'title_h2', 'description')

########################################################################################################

@admin.register(FaqPageCallToAction)
class FaqPageCallToActionAdmin(admin.ModelAdmin):
    list_display = (
        'title_1',
        'title_2',
        'button_text',
        'live_chat_button_name',
        'mail_id'
    )
    search_fields = (
        'title_1',
        'title_2',
        'description',
        'button_text',
        'live_chat_button_name',
        'mail_id'
    )

########################################################################################################

@admin.register(FaqItem)
class FaqItemAdmin(admin.ModelAdmin):
    list_display = ('question',)
    search_fields = ('question', 'answer')

########################################################################################################

@admin.register(ServicePageBanner)
class ServicePageBannerAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'tagline')
    search_fields = ('title_h1', 'description', 'tagline')

########################################################################################################

@admin.register(BenefitSection)
class BenefitSectionAdmin(admin.ModelAdmin):
    list_display = ('title_1', 'title_2')
    search_fields = ('title_1', 'title_2', 'description')

########################################################################################################

@admin.register(TeamAchievements)
class TeamAchievementsAdmin(admin.ModelAdmin):
    list_display = ('title_1', 'title_2', 'achievement_count', 'achievement_title', 'created_at')
    search_fields = ('title_1', 'title_2', 'achievement_title')

########################################################################################################

@admin.register(TeamPageBanner)
class TeamPageBannerAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'tagline')
    search_fields = ('title_h1', 'description', 'tagline')

########################################################################################################

@admin.register(TeamMember)
class TeamMemberAdmin(admin.ModelAdmin):
    list_display = ('name', 'short_info')
    search_fields = (
        'name', 'short_info', 'description', 'label1', 'value1', 'label2', 'value2',
        'label3', 'value3', 'label4', 'value4',
        'facebook_link', 'x_link', 'instagram_link', 'linkedin_link',
        'career_guideline', 'skill1_name', 'skill2_name', 'skill3_name'
    )

########################################################################################################

@admin.register(Achievement)
class AchievementAdmin(admin.ModelAdmin):
    list_display = ('number', 'title') 
    search_fields = ('title', 'description')

#########################################################################################################

@admin.register(SocialModelLinks)
class SocialModelLinksAdmin(admin.ModelAdmin):
    list_display = ('id', 'facebook_link', 'linkedin_link', 'instagram_link', 'x_link')
    search_fields = ('facebook_link', 'linkedin_link', 'instagram_link', 'x_link')

#########################################################################################################

@admin.register(TopListBanner)
class TopListBannerAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'title_h2')

#########################################################################################################

@admin.register(ExclusiveFeaturesBanner)
class ExclusiveFeaturesBannerAdmin(admin.ModelAdmin):
    list_display = ('title_h1', 'title_h2')

#########################################################################################################

@admin.register(BlogBanner)
class BlogBannerAdmin(admin.ModelAdmin):
    list_display = ('h1_title', 'h2_title', 'created_at')
    search_fields = ('h1_title', 'h2_title')

#########################################################################################################

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

#######################################################################################################

class BlogDetailInline(admin.StackedInline): 
    model = BlogDetail
    extra = 1
    readonly_fields = ('created_at',)


@admin.register(Blog)
class BlogAdmin(admin.ModelAdmin):
    list_display = (
        'title_h1',
        'author',
        'blog_category',
        'date',
        'status',
        'created_at',
    )
    list_filter = ('status', 'blog_category', 'date')
    search_fields = ('title_h1', 'meta_title', 'meta_keywords', 'slug', 'tags')
    prepopulated_fields = {"slug": ("title_h1",)}
    readonly_fields = ('created_at', 'updated_at')

    inlines = [BlogDetailInline] 

    fieldsets = (
        ("SEO Information", {
            'fields': ('meta_title', 'meta_description', 'meta_keywords', 'slug')
        }),
        ("Blog Content", {
            'fields': (
                'title_h1',
                'author',
                'blog_category',
                'description',
                'feature_image',
                'banner_image',
                'date',
                'tags',
                'status',
            )
        }),
        ("Timestamps", {
            'fields': ('created_at', 'updated_at')
        }),
    )

#####################################################################################################

@admin.register(BlogCategoryName)
class BlogCategoryNameAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'created_at')
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ('name',)
    ordering = ('name',)

######################################################################################################


class ExclusiveFeaturedDetailInline(admin.StackedInline):
    model = ExclusiveFeaturedDetail
    extra = 1
    fields = (
        'title',
        'profile_summary',
        'story_type',
        'position',
        'description',
        'banner_image',
        'alt_text',
        'tags',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'slug',
    )
    prepopulated_fields = {"slug": ("title",)}
    readonly_fields = ('created_at', 'updated_at')

    class Media:
        css = {
            'all': ('admin/css/custom_admin.css',)
        }


@admin.register(ExclusiveFeature)
class ExclusiveFeatureAdmin(admin.ModelAdmin):
    list_display = (
        'main_title', 'author', 'category', 'uploaded_date',
        'live_status', 'magazine_status', 'created_at'
    )
    list_filter = ('live_status', 'magazine_status', 'category', 'uploaded_date')
    search_fields = ('main_title', 'meta_title', 'meta_keywords', 'slug')
    prepopulated_fields = {"slug": ("main_title",)}
    readonly_fields = ('created_at', 'updated_at')

    fieldsets = (
        ("SEO Meta Info", {
            'fields': ('meta_title', 'meta_description', 'meta_keywords', 'slug')
        }),
        ("Content Info", {
            'fields': ('main_title', 'author', 'category', 'featured_image', 'uploaded_date', 'live_status')
        }),
        ("Magazine Integration", {
            'fields': ('magazine_iframe', 'magazine_status', 'magazine_slug')
        }),
        ("Timestamps", {
            'fields': ('created_at', 'updated_at')
        }),
    )

    inlines = [ExclusiveFeaturedDetailInline]  

##################################################################################################################

class TopListDetailInline(admin.StackedInline):
    model = TopListDetail
    extra = 1
    fields = ('title', 'feature_image', 'feature_image_alt_text', 'description', 'created_at', 'updated_at')
    readonly_fields = ()
    show_change_link = True


@admin.register(TopList)
class TopListAdmin(admin.ModelAdmin):
    list_display = (
        'title',
        'slug',
        'author',
        'created_at',
        'updated_at',
        'live_status',
    )
    list_filter = ('created_at',)
    search_fields = ('title', 'meta_title', 'meta_keywords', 'slug', 'tags')
    prepopulated_fields = {"slug": ("title",)}
    readonly_fields = ()

    fieldsets = (
        ("SEO Information", {
            'fields': ('meta_title', 'meta_description', 'meta_keywords', 'slug')
        }),
        ("Content", {
            'fields': (
                'title',
                'description',
                'banner_image',
                'banner_image_alt',
                'author',
                'tags',
                'live_status',
            )
        }),
        ("Timestamps", {
            'fields': ('created_at', 'updated_at')
        }),
    )

    inlines = [TopListDetailInline]


@admin.register(TopListDetail)
class TopListDetailAdmin(admin.ModelAdmin):
    list_display = (
        'title',
        'top_list',
        'created_at',
        'updated_at',
    )
    list_filter = ('created_at', 'top_list')
    search_fields = ('title', 'feature_image_alt_text')
    readonly_fields = ()

    fieldsets = (
        (None, {
            'fields': (
                'top_list',
                'title',
                'description',
                'feature_image',
                'feature_image_alt_text',
            )
        }),
        ("Timestamps", {
            'fields': ('created_at', 'updated_at')
        }),
    )

##############################################################################################

@admin.register(PageMeta)
class PageMetaAdmin(admin.ModelAdmin):
    # List view
    list_display = ("page_name", "meta_title", "og_type", "og_locale", "twitter_card")
    list_filter = ("og_type", "og_locale", "twitter_card")
    search_fields = (
        "page_name",
        "title",
        "meta_title",
        "meta_description",
        "meta_keywords",
        "og_title",
        "twitter_title",
    )

    # read-only preview helpers
    readonly_fields = (
        "twitter_image_preview",
        "og_image_preview",
        "og_image_secure_preview",
    )

    fieldsets = (
        ("Basic SEO", {
            "classes": ("wide",),
            "fields": (
                "page_name",
                "title",
                "meta_title",
                "meta_description",
                "meta_keywords",
                "canonical_url",
            ),
        }),
        ("Twitter Meta", {
            "classes": ("collapse",),
            "fields": (
                "twitter_card",
                "twitter_site",
                "twitter_creator",
                "twitter_title",
                "twitter_image",
                "twitter_image_alt",
                "twitter_image_preview",
            ),
        }),
        ("Open Graph", {
            "classes": ("collapse",),
            "fields": (
                "og_title",
                "og_url",
                "og_image",
                "og_image_type",
                "og_image_width",
                "og_image_height",
                "og_type",
                "og_locale",
                "og_image_url",
                "og_image_secure_url",
                "og_site_name",
                "og_see_also",
                "og_image_preview",
                "og_image_secure_preview",
            ),
        }),
        ("Additional Meta", {
            "classes": ("wide",),
            "fields": (
                "article_author",
                "google_site_verification",
            ),
        }),
    )

    # -------- Image preview helpers (safe for Add & Change) --------
    def twitter_image_preview(self, obj):
        if not obj or not obj.twitter_image:
            return "—"
        return format_html(
            '<img src="{}" style="max-width:240px;height:auto;border:1px solid #eee;" />',
            obj.twitter_image.url
        )
    twitter_image_preview.short_description = "Twitter Image Preview"

    def og_image_preview(self, obj):
        if not obj or not obj.og_image:
            return "—"
        return format_html(
            '<img src="{}" style="max-width:240px;height:auto;border:1px solid #eee;" />',
            obj.og_image.url
        )
    og_image_preview.short_description = "OG Image Preview"

    def og_image_secure_preview(self, obj):
        if not obj or not obj.og_image_secure_url:
            return "—"
        return format_html(
            '<img src="{}" style="max-width:240px;height:auto;border:1px solid #eee;" />',
            obj.og_image_secure_url.url
        )
    og_image_secure_preview.short_description = "OG Secure Image Preview"
