from .models import FooterDetail, SocialModelLinks
from .forms import MagazineSubscriptionForm

def footer_data(request):
    footer = FooterDetail.objects.first()
    return {'footer_detail': footer}

def magazine_form(request):
    return {'magazine_form': MagazineSubscriptionForm()}

def social_links_context(request):
    social_links = SocialModelLinks.objects.first()
    return {'global_social_links': social_links}
